export default function Contact(){
  return (
    <div className="page">
      <main className="container" style={{padding:'60px 20px'}}>
        <h1>Kontakt</h1>
        <p>Masz pytanie? Napisz na: kontakt@taskai.pl (adres przykładowy)</p>
        <p>Możesz też skorzystać z formularza w przyszłym wydaniu strony.</p>
      </main>
    </div>
  )
}
