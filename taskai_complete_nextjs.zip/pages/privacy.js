export default function Privacy(){
  return (
    <div className="page">
      <main className="container" style={{padding:'60px 20px'}}>
        <h1>Polityka prywatności (prosta wersja)</h1>
        <p>Ta strona nie zbiera aktualnie danych osobowych. Jeśli wprowadzimy newsletter lub formularz kontaktowy, polityka zostanie rozszerzona.</p>
      </main>
    </div>
  )
}
