TaskAI - Complete Next.js starter (multi-page)

Instrukcje szybkie:
1. Rozpakuj archiwum.
2. Zainstaluj Node.js LTS (jeśli jeszcze nie masz): https://nodejs.org
3. W terminalu, w katalogu projektu, uruchom:
   npm install
   npm run dev
4. Otwórz przeglądarkę: http://localhost:3000

Deploy: polecam Vercel (bez konfiguracji) lub dowolny hosting Next.js.
Plik CNAME w katalogu /public zawiera: taskai.pl
